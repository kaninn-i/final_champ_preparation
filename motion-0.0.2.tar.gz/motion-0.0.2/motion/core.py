#!/usr/bin/python3

#
#   Developer : Mikhail Filchenkov (m.filchenkov@gmail.com)
#   All rights reserved. Copyright (c) 2025 Applied Robotics.
#

import os
import motorcortex
from math import *
from robot_control.motion_program import Waypoint, MotionProgram, PoseTransformer
from robot_control.robot_command import RobotCommand
from robot_control.system_defs import InterpreterStates, States, ModeCommands
from .system_def import Path, JoyVelicity
import logging
from importlib.resources import files
import socket
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[%(levelname)s] %(message)s')
    # handler.setFormatter(formatter)
    # logger.addHandler(handler)

class LedLamp(object):
    """
    Class represents a control led lamp of the robot ARM.
    Args:
        ip(str): IP-address robot ARM
        port(str): Port robot ARM

    """

    def __init__(self, ip='192.168.2.101', port=8890):
        self.__hostname = ip
        self.__port = port
        self.timeout = 0.2
        
    def setLamp(self, status: str):
        """
        Set light to the lamp.
            Args:
                state: status for each color

            Description:
                The status for the "state" variable is written in the sequence:
                  - 1111 to turn on all colors
                  - 0000 to turn off all colors 
            
                - The first digit corresponds (**1**000) -> blue color
                - The second digit corresponds (0**1**00) -> green color
                - The third digit corresponds (00**1**0) -> yellow color
                - The fourth digit corresponds (000**1**) -> red color
        """
       
        if len(status) != 4 or not all(c in "01" for c in status):
            logger.error("The status must be a string of four characters containing only '0' or '1'.")
            return
    
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.sendto(status.encode(), (self.__hostname, self.__port))
                logger.info(f"Set led lamp: {status}")
        except Exception as e:
            logger.exception(f"Error when sending UDP: {e}")

class RobotControl(object):
    """
    Class represents a control machine of the robot ARM.
    Args:
        ip(str): IP-address robot ARM
        port(str): Port robot ARM
        login(str): login robot ARM
        password(str): password robot ARM

    """
        
    def __init__(self, ip='192.168.2.100', port='5568:5567', login='*', password='*'):
        self.__hostname = ip
        self.__port = port
        self.__login = login
        self.__password = password
        self.__pathCert = files("motion").joinpath("mcx.cert.pem")
        self.__certificate = [str(self.__pathCert)]
        self.__timeout = 0.4
        
    def connect(self):
        """
        Connect to the robot ARM
            Returns:
                bool: True if operation is completed, False if failed
            
        """
        
        parameter_tree = motorcortex.ParameterTree()
        self.__messageTypes = motorcortex.MessageTypes()
        try:
            self.__req, sub = motorcortex.connect("wss://" + self.__hostname + ":" + self.__port,
                                                self.__messageTypes, parameter_tree,
                                                certificate=self.__certificate, timeout_ms=1000,
                                                login=self.__login, password=self.__password)
            
            self.__robot = RobotCommand(self.__req, self.__messageTypes)
            logger.info("Robot ARM connected")
            return True
        
        except RuntimeError as err:
            logger.error(err)
            return False
        
    def engage(self):
        """
        Engage motor to the robot ARM
            Returns:
                bool: True if operation is completed, False if failed
        
        """
        try:
            if self.__robot.engage():
                time.sleep(self.__timeout)
                logger.info("Robot is Engage")
                return True
                
        except RuntimeError as err:
            logger.error(err)
            return False
        
    def disengage(self):
        """
        Disngage motor to the robot ARM
            Returns:
                bool: True if operation is completed, False if failed
        
        """
        try:
            if self.__robot.disengage():
                self.__robot.off()
                logger.info("Robot is Disengage")
                return True
            
        except RuntimeError as err:
            logger.error(err)
            return False

    def manualCartMode(self):
        """
        Set manual cartesian mode for robot ARM.
            Returns:
                bool: True if operation is completed, False if failed
        
        """

        try:
            if self.__robot.manualCartMode():
                time.sleep(self.__timeout)
                logger.info("Cartesian mode active")
                return True
            
        except RuntimeError as err:
            logger.error(err)
            return False
        
    def manualJointMode(self):
        """
        Set manual joint mode for robot ARM.
            Returns:
                bool: True if operation is completed, False if failed
        
        """

        try:
            if self.__robot.manualJointMode():
                time.sleep(self.__timeout)
                logger.info("Joint mode active")
                return True
            
        except RuntimeError as err:
            logger.error(err)
            return False

    def setJointVelocity(self, velicity=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]):
        """"x":500,"y":300,"wires":[["c792513c7cebc03c"]]},
        Robot ARM control in joint mode by joysticks.
            Args:
                velocity(list(double)): joint velocity (motor1, motor2, motor3, motor4, motor5, motor6)

            Returns:
                bool: ARM parameter if operation is completed, False if failed
        
        """

        actual_state = self.__req.getParameter(Path.ROBOT_MODE.value).get().value[0]
        if actual_state is ModeCommands.GOTO_MANUAL_JOINT_MODE_E.value:
            if len(velicity) == 6:
                cap_vel = self.__cap_velocity(velicity, JoyVelicity.MAX_JOY_VELOCITY_JOINT.value)
                return self.__req.setParameter(Path.HOSTIN_JOINT_VELOCITY.value, cap_vel).get()
            else:
                logger.warning("The number of values doesn't correspond to the number of motors")
                return False

        else:
            logger.info("Actual robot state isn't joint mode")
            return False
        
    def setCartesianVelocity(self, velicity=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0]):
        """
        Robot ARM control in cartesian mode by joysticks.
            Args:
                velocity(list(double)): cartesian velocity (x, y, z, rx, ry, rz)

            Returns:
                bool: ARM parameter if operation is completed, False if failed
        
        """

        actual_state = self.__req.getParameter(Path.ROBOT_MODE.value).get().value[0]
        if actual_state is ModeCommands.GOTO_MANUAL_CART_MODE_E.value:
            if len(velicity) == 6:
                cap_vel = self.__cap_velocity(velicity, JoyVelicity.MAX_JOY_VELOCITY_CARTESIAN.value)
                return self.__req.setParameter(Path.HOSTIN_TOOL_VELOCITY.value, cap_vel).get()
            else:
                logger.warning("The number of values doesn't correspond to the tool")
                return False

        else:
            logger.info("Actual robot state isn't cartesian mode")
            return False
    
    def moveToStart(self):
        """
        Robot ARM control in cartesian mode by joysticks.
            Returns:
                bool: ARM parameter if operation is completed, False if failed
        
        """
        self.__robot.semiAutoMode()
        motion_program = MotionProgram(self.__req, self.__messageTypes)    
        start_point = []
        start_point.append(Waypoint([radians(0), radians(0), radians(90), radians(0), radians(90), radians(0)]))
        motion_program.addMoveJ(start_point, 0.05, 0.1)

        motion_program.send("move_to_start_point").get() 
        # self.__robot.play(wait_time=0.25)

        if self.__robot.play(wait_time=0.25) is InterpreterStates.MOTION_NOT_ALLOWED_S.value:
            if self.__robot.moveToStart(200):
                logger.info("Robot move to start position")
            else:
                logger.warning('Failed to move to the start position')
            
        motion_program.send("move_to_start_point").get() 
        self.__robot.play(wait_time=0.25)

        while not(self.__robot.play(wait_time=0.25) is InterpreterStates.PROGRAM_IS_DONE.value):
            pass
        else:
            logger.info('Robot is at the start position')
            return True
        
    def activateMoveToStart(self):
        """
        Manual activate move to start robot ARM.
        Description:
            Used for the button
        
        """
        logger.info("Robot move to start")
        self.__req.setParameter(Path.ACTIVATE_MOVE_TO_START.value, 1).get()
    
    def moveToPointL(self, waypoint_list, velocity=0.1, acceleration=0.2,
                 rotational_velocity=3.18, rotational_acceleration=6.37,
                 ref_joint_coord_rad=[]):
        """
        Adds a MoveL(Linear move) command to the program
        Args:
            waypoint_list(list(WayPoint)): a list of waypoints
            velocity(double): maximum velocity, m/sec
            acceleration(double): maximum acceleration, m/sec^2
            rotational_velocity(double): maximum joint velocity, rad/sec
            rotational_acceleration(double): maximum joint acceleration, rad/sec^2
            ref_joint_coord_rad: reference joint coordinates for the first waypoint
        Description:
            Waypoint([x, y, z, rx, ry, rz]) - the waypoint is set as the absolute position of the manipulator in meters

        """

        self.__robot.semiAutoMode()
        motion_program = MotionProgram(self.__req, self.__messageTypes) 
        motion_program.addMoveL(waypoint_list, velocity, acceleration,
                 rotational_velocity, rotational_acceleration,
                 ref_joint_coord_rad)
        motion_program.send("move_to_point_l").get() 
        time.sleep(self.__timeout)

    def moveToPointC(self, waypoint_list, angle, velocity=0.1, acceleration=0.2,
                 rotational_velocity=3.18, rotational_acceleration=6.37,
                 ref_joint_coord_rad=[]):
        
        """
        Adds a MoveC(circular move) command to the program
        Args:
            waypoint_list(list(WayPoint)): a list of waypoints
            angle(double): rotation angle, rad
            velocity(double): maximum velocity, m/sec
            acceleration(double): maximum acceleration, m/sec^2
            rotational_velocity(double): maximum joint velocity, rad/sec
            rotational_acceleration(double): maximum joint acceleration, rad/sec^2
            ref_joint_coord_rad: reference joint coordinates for the first waypoint
        Description:
            Waypoint([x, y, z, rx, ry, rz]) - the waypoint is set as the absolute position of the manipulator 
            x, y, z in meters (example: 0.85, -0.191, 0.921)
            rx, ry, rz in radians (example: pi/2, 0, pi)
        """
                
        self.__robot.semiAutoMode()
        motion_program = MotionProgram(self.__req, self.__messageTypes) 
        motion_program.addMoveC(waypoint_list, angle, velocity, acceleration,
                 rotational_velocity, rotational_acceleration,
                 ref_joint_coord_rad)
        motion_program.send("move_to_point_c").get() 
        time.sleep(self.__timeout)

    def moveToPointJ(self, waypoint_list=[], rotational_velocity=3.18, rotational_acceleration=6.37):
        """
        Adds MoveJ(Joint move) command to the program
        Args:
            waypoint_list(list(WayPoint)): a list of waypoints
            rotational_velocity(double): maximum joint velocity, rad/sec
            rotational_acceleration(double): maximum joint acceleration, rad/sec^2
        Description:
            Waypoint(0.0, 0.0, 1.57, 0.0, 1.57, 0.0) - the waypoint is set as the position of the motors in radians

        """
        self.__robot.semiAutoMode()
        motion_program = MotionProgram(self.__req, self.__messageTypes) 
        motion_program.addMoveJ(waypoint_list, rotational_velocity, rotational_acceleration)
        motion_program.send("move_to_point_j").get() 
        time.sleep(self.__timeout)

    def play(self):
        """
        Needed for start robot programm
            Returns:
                InterpreterStates: actual state of the interpreter
        """
        logger.info("Robot programm play")
        if self.__robot.play(wait_time=0.25) is InterpreterStates.MOTION_NOT_ALLOWED_S.value:
            logger.info("Robot don't in start position")
        return self.__robot.play(wait_time=0.25)
    

    def pause(self):
        """
        Needed for pause robot programm
            Returns:
                InterpreterStates: actual state of the interpreter
        """
        logger.info("Robot programm pause")
        return self.__robot.pause()

    def stop(self):
        """
        Needed for stop robot programm
            Returns:
                InterpreterStates: actual state of the interpreter
        """
        logger.info("Robot programm stop")
        return self.__robot.stop()

    def reset(self):
        """
        Needed for reset robot programm
            Returns:
                InterpreterStates: actual state of the interpreter
        """
        logger.info("Robot programm reset")
        return self.__robot.reset()

    def toolON(self):
        """
        Turns on the working tool
            Description:
                If there is a vacuum system, the suction cup is activated.
                In the presence of a gripping device, the grip is compressed.
            Returns:
                InterpreterStates: Tool of the IO
        """
        logger.info("Robot programm play")
        return self.__req.setParameter(Path.TOOL_CMD.value, 1).get()
    
    def toolOFF(self):
        """
        Turns off the working tool
            Description:
                If there is a vacuum system, the suction cup is disactivated.
                In the presence of a gripping device, the grip is unclenches.
            Returns:
                InterpreterStates: Tool of the IO
        """
        logger.info("Robot programm play")
        return self.__req.setParameter(Path.TOOL_CMD.value, 0).get()
    
    def getRobotMode(self):
        """
        Returns:
            InterpreterStates: actual robot mode

        """
        
        return self.__req.getParameter(Path.ROBOT_MODE.value).get().value[0]
    
    def getRobotState(self):
        """
        Returns:
            InterpreterStates: actual robot state

        """
        
        return self.__req.getParameter(Path.ROBOT_STATE.value).get().value[0]
    
    def getActualStateOut(self):
        """
        Returns:
            InterpreterStates: actual state of the interpreter

        """
        return self.__req.getParameter(Path.STATE_CMD.value).get().value[0]
    
    def getMotorPositionTick(self):
        """
        Returns:
            list(float): actual encoder positions
        """
        return [self.__req.getParameter(tick).get().value[0] for tick in Path.CURRENT_JOINT_POSE_TICK.value]

    def getToolPosition(self):
        """
        Returns:
            list(float): actual tool positions
        """

        return self.__req.getParameter(Path.CURRENT_TOOL_POSE.value).get().value

    def getMotorPositionRadians(self):
        """
        Returns:
            list(float): actual motor positions in radians
        """
        return self.__req.getParameter(Path.CURRENT_JOINT_POSE_RADIANS.value).get().value
    
    def getManipulability(self):
        """
        Description:
            Ability to maneuver range 0..1
            0 - critical situation
            1 - safe situation
        
        Returns:
            float: actual manipulability
        """
                
        return self.__req.getParameter(Path.MANIPULABILITY_CMD).get().value[0]
        
    def getActualTemperature(self):
        """
        Returns:
            float: actual motor temperature
        """
                
        self.__req.setParameter(Path.READSDO_CMD.value, 1).get()
        return self.__req.getParameter(Path.MANIPULABILITY_CMD).get().value[0]

        
    def __cap_velocity(self, velocities, max_velocity):
        return [min(max(velocity, -max_velocity), max_velocity) for velocity in velocities]

    